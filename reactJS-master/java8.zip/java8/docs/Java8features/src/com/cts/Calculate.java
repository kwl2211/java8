package com.cts;
	public class Calculate {  
	    int add(int a, int b){  
	        return (a+b);  
	    }  
	    int mul(int a, int b){  
	        return (b*a);  
	    }  
	    String getMesssage(String msg)
	    {
	    	return msg;
	    }
	}  
