package coreservlets.comparator;

public class StringSorter1Test {
  public static void main(String[] args) {
    StringSorter1.doTests();
  }
}
