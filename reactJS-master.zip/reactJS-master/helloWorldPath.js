var path = require("path");



console.log(path.dirname(__filename));



