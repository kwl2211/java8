

global.console.log("Hello Node");


console.log(`I am working with {__dirname}`);
