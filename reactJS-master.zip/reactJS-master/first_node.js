var server = require("http");

server.createServer().listen(9999);
        
console.log('Node HTTP Blank Server started at port 9999');