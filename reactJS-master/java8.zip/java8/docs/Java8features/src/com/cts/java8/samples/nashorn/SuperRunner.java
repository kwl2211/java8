package com.cts.java8.samples.nashorn;

/**
 * @author Benjamin Winterberg
 */
public class SuperRunner implements Runnable {

    @Override
    public void run() {
        System.out.println("super run");
    }

}