var message = "Node variable";

var slicedMessage = message.slice(1,4);

global.console.log(`this is sliced message: ${slicedMessage}`);

console.log(__dirname);

console.log(__filename);