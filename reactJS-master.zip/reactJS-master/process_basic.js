var process = require('process');

console.log(process.argv);