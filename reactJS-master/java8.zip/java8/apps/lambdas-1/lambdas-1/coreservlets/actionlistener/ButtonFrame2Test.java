package coreservlets.actionlistener;

public class ButtonFrame2Test {
  public static void main(String[] args) {
    new ButtonFrame2();
  }
}