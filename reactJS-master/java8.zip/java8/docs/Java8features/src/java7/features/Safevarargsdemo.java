package features;

public class Safevarargsdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
